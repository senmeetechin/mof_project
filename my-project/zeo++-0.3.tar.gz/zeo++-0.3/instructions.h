
/* This function prints program instructions when Zeo++ is executed without parameters.
 */

#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

void PrintInstructions();

#endif
